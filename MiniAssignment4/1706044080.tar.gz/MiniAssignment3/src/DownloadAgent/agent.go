package main

import (
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"io"
	"log"
	"math/rand"
	"net"
	"net/http"
	"os"
	"path"
	"strconv"
	"time"

	pb "projectLAW/MiniAssignment3/src/miniproject3"

	"github.com/streadway/amqp"
	"google.golang.org/grpc"
)

type Message struct {
	Content string `json:"content"`
	Status  string `json:"status"`
}

type server struct{}

var ch *amqp.Channel

func failOnError(err error, msg string) {
	if err != nil {
		log.Fatalf("%s: %s", msg, err)
	}
}

func RandomInteger(min int, max int) int {
	// Helper func
	return min + rand.Intn(max-min)
}

func RandomString(n int) string {
	//Helper func
	bytes := make([]byte, n)

	for i := 0; i < n; i++ {
		bytes[i] = byte(RandomInteger(97, 122))
	}

	return string(bytes)
}

func PrintDownloadPercent(done chan int64, path string, total int64, uniqId string) {

	var stop bool = false

	for {
		select {
		case <-done:
			stop = true
		default:

			file, err := os.Open(path)
			if err != nil {
				log.Fatal(err)
			}

			fi, err := file.Stat()
			if err != nil {
				log.Fatal(err)
			}

			size := fi.Size()

			if size == 0 {
				size = 1
			}

			var percent float64 = float64(size) / float64(total) * 100

			payload := Message{Content: string(strconv.Itoa(int(percent))), Status: "In Progress"}
			payloadStr, err := json.Marshal(payload)

			err = ch.Publish(
				"remotedownload", // exchange
				uniqId,           // routing key
				false,            // mandatory
				false,            // immediate
				amqp.Publishing{
					ContentType: "text/plain",
					Body:        []byte(payloadStr),
				})
			failOnError(err, "Failed to publish a message")

			fmt.Printf("%.0f", percent)
			fmt.Println("%")
		}

		if stop {
			break
		}

		time.Sleep(time.Millisecond * 5)
	}
}

func DownloadFile(url string, dest string, uniqId string) {
	// Small files tend to get skipped to give progress, so we sleep first
	time.Sleep(time.Second * 1)

	file := path.Base(url)

	log.Printf("Downloading file %s from %s\n", file, url)

	var path bytes.Buffer
	path.WriteString(dest)

	// If no directory with that name, create one then
	if _, err := os.Stat(path.String()); os.IsNotExist(err) {
		os.Mkdir(path.String(), 0755)
	}

	path.WriteString("/")
	path.WriteString(file)

	start := time.Now()

	out, err := os.Create(path.String())

	if err != nil {
		fmt.Println(path.String())
		panic(err)
	}

	defer out.Close()

	headResp, err := http.Head(url)

	if err != nil {
		panic(err)
	}

	defer headResp.Body.Close()

	size, err := strconv.Atoi(headResp.Header.Get("Content-Length"))

	if err != nil {
		panic(err)
	}

	done := make(chan int64)

	go PrintDownloadPercent(done, path.String(), int64(size), uniqId)

	resp, err := http.Get(url)

	if err != nil {
		panic(err)
	}

	defer resp.Body.Close()

	n, err := io.Copy(out, resp.Body)

	if err != nil {
		panic(err)
	}

	done <- n

	payload := Message{Content: "/storage/" + file, Status: "File saved"}
	payloadStr, err := json.Marshal(payload)
	err = ch.Publish(
		"remotedownload", // exchange
		uniqId,           // routing key
		false,            // mandatory
		false,            // immediate
		amqp.Publishing{
			ContentType: "text/plain",
			Body:        []byte(payloadStr),
		})
	failOnError(err, "Failed to publish a message")

	elapsed := time.Since(start)

	log.Printf("Download completed in %s", elapsed)
}

func (s server) Download(ctx context.Context, request *pb.DownloadRequest) (*pb.DownloadResponse, error) {
	linkDownload := &request.Url
	randomString := RandomString(10)

	// Download file asynchronously
	go DownloadFile(*linkDownload, "../storage", randomString)

	return &pb.DownloadResponse{Url: *linkDownload, UniqId: randomString}, nil
}

func main() {

	// Dial rabbitMQ
	conn, err := amqp.Dial("amqp://guest:guest@localhost:5672/")
	failOnError(err, "Failed to connect to RabbitMQ")
	defer conn.Close()

	// Try to open rabbitMQ channel
	ch, err = conn.Channel()
	failOnError(err, "Failed to open a channel")
	defer ch.Close()

	// Declare new rabbitMQ exchange
	err = ch.ExchangeDeclare(
		"remotedownload", // name
		"direct",         // type
		true,             // durable
		false,            // auto-deleted
		false,            // internal
		false,            // no-wait
		nil,              // arguments
	)
	failOnError(err, "Failed to declare an exchange")

	// create listener
	lis, err := net.Listen("tcp", ":50005")
	if err != nil {
		log.Fatalf("failed to listen: %v", err)
	}

	// create grpc server
	s := grpc.NewServer()
	pb.RegisterMiniProjectServiceServer(s, server{})

	log.Println("Starting new GRPC server on port 50005")

	// and start...
	if err := s.Serve(lis); err != nil {
		log.Fatalf("failed to serve: %v", err)
	}
}
