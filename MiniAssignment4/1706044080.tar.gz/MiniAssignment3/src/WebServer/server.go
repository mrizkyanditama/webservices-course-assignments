package main

import (
	"fmt"
	"log"
	"net/http"

	pb "projectLAW/MiniAssignment3/src/miniproject3"

	"github.com/gin-gonic/contrib/static"
	"github.com/gin-gonic/gin"
	"google.golang.org/grpc"
)

func main() {
	router := gin.Default()
	router.LoadHTMLGlob("templates/*")
	router.Use(static.Serve("/storage", static.LocalFile("../storage", false)))

	router.GET("/download", func(c *gin.Context) {
		c.HTML(http.StatusOK, "download.html", gin.H{})
	})

	router.POST("/download", func(c *gin.Context) {
		// single file
		inputUrl := c.PostForm("inputUrl")
		if inputUrl == "" {
			c.JSON(http.StatusUnprocessableEntity, gin.H{
				"status": http.StatusUnprocessableEntity,
				"error":  "Input url is missing or empty",
			})
			return
		}

		// dail server
		conn, err := grpc.Dial(":50005", grpc.WithInsecure())
		if err != nil {
			log.Fatalf("can not connect with server %v", err)
		}

		// create client instance
		client := pb.NewMiniProjectServiceClient(conn)
		response, err := client.Download(c.Request.Context(), &pb.DownloadRequest{Url: inputUrl})

		// // Check if server 2 succesfully accept the file
		if response.UniqId != "" {
			c.HTML(http.StatusOK, "progress.html", gin.H{"routingKey": response.UniqId})
		} else {
			c.String(http.StatusOK, fmt.Sprintf("'%s' failed to be download", inputUrl))
		}

	})
	router.Run(":8001")
}
